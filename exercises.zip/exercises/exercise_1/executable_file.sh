#!/bin/bash

echo "I'm an executable file!"
echo "You can run me with the command: $0"
echo "I will then print this text to the screen..."
echo -e "And will also list the content of the current directory: $PWD\n"

ls -l .

echo -e "\nThat's all I can do. Bye for now."
